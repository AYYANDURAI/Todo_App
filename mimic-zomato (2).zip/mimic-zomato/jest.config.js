module.exports = {
    testEnvironment: 'jsdom',
  transform: {
    '^.+\\.[tj]sx?$': 'babel-jest',
  },
  moduleNameMapper: {
    '\\.(css|less|scss)$': 'identity-obj-proxy',
  },
    // Use jsdom as the test environment (default for React projects)
    
    // Specify file extensions to include in testing
    moduleFileExtensions: ['js', 'jsx', 'json', 'node'],
    
    // Automatically clear mocks and timers between tests
    clearMocks: true,
  
    // Transform JSX and ES6/ES7 code with Babel
    transform: {
      '^.+\\.[tj]sx?$': 'babel-jest',
    },
  
    // Configure module resolution for imports in tests
    moduleNameMapper: {
      // If you have specific aliases or if you want to mock assets (like CSS or images), you can map them here
      '\\.(css|less|scss)$': 'identity-obj-proxy',
    },
  
    // Optionally, collect code coverage
    collectCoverage: true,
  
    // Specify the directories for Jest to look for test files
    roots: ['<rootDir>/src'],
  
    // Watch mode options (helpful when running tests in development)
    watchPathIgnorePatterns: ['/node_modules/'],
  };
  