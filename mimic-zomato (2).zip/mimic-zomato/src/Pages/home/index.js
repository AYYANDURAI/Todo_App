import React, { useState } from "react";
import Header from "../../Components/Common/header";
import TabOptions from "../../Components/Common/tabOptions";
import Footer from "../../Components/Common/footer";
import Delivery from "../../Components/Common/Delivery";
import DiningOut from "../../Components/Common/Delivery";
import FoodGrid from "../../Components/restaurants";

const HomePage = () => {
  const [activeTab, setActiveTab] = useState("Delivery");
  return (
    <div className="max-width">
      <Header />
      <TabOptions activeTab={activeTab} setActiveTab={setActiveTab} />
      {getCorrectScreen(activeTab)}
      <FoodGrid />
      <Footer />
    </div>
  );
};

const getCorrectScreen = (tab) => {
  switch (tab) {
    case "Delivery":
      return <Delivery />;
    case "Dining Out":
      return <DiningOut />;
    default:
      return <Delivery />;
  }
};

export default HomePage;
