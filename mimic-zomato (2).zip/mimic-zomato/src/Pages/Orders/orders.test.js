import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom"; // For jest-dom matchers
import { Provider } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
import foodItems from "../../MockData/foodItems.json";
import restaurants from "../../MockData/restaurants.json";
import React from 'react'; // Import React at the top of your test file
import { BrowserRouter as Router } from "react-router-dom";
import Orders from "./index";

const mockStore = configureStore({
    reducer: {
      cart: (
        state = {
          cart: [
            {
              id: 1,
              name: "",
              image_url: "",
              price: 200,
              qty: 1,
              restId: 2,
              restaurant: restaurants[0],
            },
          ],
        }
      ) => state,
      restaurants: (
        state = {
          filteredRestaurants: [...restaurants],
          filters: {
            rating: false,
            isVeg: false,
            isNonVeg: false,
            deliveryTime: null,
          },
        }
      ) => state,
      foodItems: (
        state = {
          filteredFoodItems: [...foodItems],
          foodFilters: {
            mainCourse: false,
            starter: false,
            dessert: false,
            soups: false,
          },
        }
      ) => state,
      orders: (
        state = {
          orders: [
            {
                id: 1,
                restaurant: {
                  image: "https://example.com/image.jpg",
                  name: "Test Restaurant",
                  location: "Test Location",
                },
                items: [
                  { id: 1, name: "Pizza", qty: 2 },
                  { id: 2, name: "Burger", qty: 1 },
                ],
                date: "2025-01-19",
                time: "12:30 PM",
                price: 350,
              }
          ],
        }
      ) => state,
    },
  });
  

const renderWithStore = (store) => {
  return render(
    <Provider store={store}>
      <Router>
        <Orders />
      </Router>
    </Provider>
  );
};

describe("Orders Component", () => {
  it("renders without crashing", () => {
    renderWithStore(mockStore);
    expect(screen.getByText("Your Orders")).toBeInTheDocument();
  });

  it("displays the correct order information", () => {
    
    renderWithStore(mockStore);

    expect(screen.getByText("Test Restaurant")).toBeInTheDocument();
    expect(screen.getByText("Test Location")).toBeInTheDocument();
    expect(screen.getByText("2 x Pizza")).toBeInTheDocument();
    expect(screen.getByText("1 x Burger")).toBeInTheDocument();
    expect(screen.getByText("Order placed on 2025-01-19, 12:30 PM")).toBeInTheDocument();
    expect(screen.getByText("₹350")).toBeInTheDocument();
  });

  it("displays multiple orders correctly", () => {
    
    renderWithStore(mockStore);
    
    // Expect two orders to be rendered
    expect(screen.getAllByText("Test Restaurant").length).toBe(1);
    expect(screen.getAllByText("2 x Pizza").length).toBe(1);
  });

  it("renders restaurant image correctly", () => {
   
    renderWithStore(mockStore);

    const img = screen.getByAltText("restaurant-img");
    expect(img).toHaveAttribute("src", "https://example.com/image.jpg");
  });

  it("displays 'View Menu' link for each order", () => {
    renderWithStore(mockStore);

    const viewMenuLink = screen.getByText("View Menu");
    expect(viewMenuLink).toBeInTheDocument();
  });
});
