import React from "react";
import Card from "react-bootstrap/Card";
import Header from "../../Components/Common/header";
import { useSelector } from "react-redux";
import "./orders.css";

const Orders = () => {
  const { orders } = useSelector((state) => state.orders);
  console.log(orders);
  return (
    <div>
      <Header />
      <div className="orders-page max-width">
        <div className="orders-heading">
          <h6>Your Orders</h6>
        </div>
        {orders.map((order, i) => {
          return (
            <Card className="orders" key={i}>
              <Card.Header className="orders-header">
                <img
                  className="restaurant-img"
                  src={order.restaurant.image}
                  alt="restaurant-img"
                />
                <div className="orders-info">
                  <span className="restaurant-title">
                    {order.restaurant.name}
                  </span>
                  <span className="restaurant-address">
                    {order.restaurant.location}
                  </span>
                  <div className="view-menu">
                    <span>View Menu</span>
                    <i className="fi fi-sr-caret-right vmr-icon" />
                  </div>
                </div>
              </Card.Header>
              <Card.Body className="orders-content">
                <div>
                  {order.items.map((item) => {
                    return (
                      <div key={item.id} className="order-item">
                        <i className="fi fi-sr-caret-right right-icon" />
                        <span>{item.qty} x {item.name}</span>
                      </div>
                    );
                  })}
                </div>
                <div className="order-date-price">
                  <p className="order-date">
                    Order placed on {order.date}, {order.time}
                  </p>
                  <span className="order-price"> ₹{order.price}</span>
                </div>
              </Card.Body>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default Orders;
