import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import UncontrolledExample from './index';

// Mock the entire react-bootstrap/Carousel module
jest.mock('react-bootstrap/Carousel', () => {
  const Carousel = ({ children }) => (
    <div data-testid="carousel">{children}</div>
  );
  
  // Add Item as a property to Carousel
  Carousel.Item = ({ children }) => (
    <div data-testid="carousel-item">{children}</div>
  );
  
  return Carousel;
});

describe('UncontrolledExample Component', () => {
  const expectedImages = [
    'https://b.zmtcdn.com/web_assets/81f3ff974d82520780078ba1cfbd453a1583259680.png',
    'https://b.zmtcdn.com/data/collections/17d0b2714f18e5976c845bef1a2dc4a5_1627465505.jpg',
    'https://b.zmtcdn.com/data/pictures/chains/8/18737018/0e79614ea14113b8b3d4b48574293d00.jpg'
  ];

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Rendering', () => {
    it('renders the carousel component', () => {
      render(<UncontrolledExample />);
      expect(screen.getByTestId('carousel')).toBeInTheDocument();
    });

    it('renders correct number of carousel items', () => {
      render(<UncontrolledExample />);
      const items = screen.getAllByTestId('carousel-item');
      expect(items).toHaveLength(3);
    });

    it('renders all images with correct attributes', () => {
      render(<UncontrolledExample />);
      const images = screen.getAllByAltText('icon');
      
      expect(images).toHaveLength(3);
      
      images.forEach((img, index) => {
        expect(img).toHaveAttribute('src', expectedImages[index]);
        expect(img).toHaveAttribute('alt', 'icon');
        expect(img).toHaveClass('food-img');
      });
    });
  });

  describe('Image Properties', () => {
    it('verifies each image source', () => {
      render(<UncontrolledExample />);
      const images = screen.getAllByRole('img');
      
      expectedImages.forEach((src, index) => {
        expect(images[index]).toHaveAttribute('src', src);
      });
    });

    it('verifies each image has correct class and alt text', () => {
      render(<UncontrolledExample />);
      const images = screen.getAllByRole('img');
      
      images.forEach(img => {
        expect(img).toHaveClass('food-img');
        expect(img).toHaveAttribute('alt', 'icon');
      });
    });
  });

  describe('Accessibility', () => {
    it('ensures all images have alt text', () => {
      render(<UncontrolledExample />);
      const images = screen.getAllByRole('img');
      images.forEach(img => {
        expect(img).toHaveAttribute('alt');
      });
    });
  });
});