import Carousel from "react-bootstrap/Carousel";
import "./index.css";
import React from 'react'; // Import React at the top of your test file

function UncontrolledExample() {
  return (
    <div className="caro">
      <Carousel>
        <Carousel.Item>
          <img
            className="food-img"
            alt="icon"
            src="https://b.zmtcdn.com/web_assets/81f3ff974d82520780078ba1cfbd453a1583259680.png"
          />
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="food-img"
            alt="icon"
            src="https://b.zmtcdn.com/data/collections/17d0b2714f18e5976c845bef1a2dc4a5_1627465505.jpg"
          />
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="food-img"
            alt="icon"
            src="https://b.zmtcdn.com/data/pictures/chains/8/18737018/0e79614ea14113b8b3d4b48574293d00.jpg"
          />
        </Carousel.Item>
      </Carousel>
    </div>
  );
}

export default UncontrolledExample;
