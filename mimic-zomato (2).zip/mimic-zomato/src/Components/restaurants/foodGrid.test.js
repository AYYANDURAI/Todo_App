import { render, screen, fireEvent } from "@testing-library/react";
import { BrowserRouter as Router } from "react-router-dom";
import { Provider } from "react-redux";
import FoodGrid from "./index";
import { configureStore } from "@reduxjs/toolkit";
import restaurants from '../../MockData/restaurants.json';
import foodItems from '../../MockData/foodItems.json';
import { useNavigate } from 'react-router-dom';
// Mock Redux store and initial state
const mockStore = configureStore({
    reducer: {
      cart: (
        state = {
          cart: [
            {
              id: 1,
              name: "",
              image_url: "",
              price: 200,
              qty: 1,
              restId: 2,
              restaurant: restaurants[0],
            },
          ],
        }
      ) => state,
      restaurants: (
        state = {
          filteredRestaurants: [ {
            id: 1,
            name: "Restaurant 1",
            image: "https://example.com/restaurant1.jpg",
            rating: 4.5,
            foodType: "Fast Food",
            price: "₹250",
            deliveryTime: "30 mins",
          }],
          filters: {
            rating: false,
            isVeg: false,
            isNonVeg: false,
            deliveryTime: null,
          },
        }
      ) => state,
      foodItems: (
        state = {
          filteredFoodItems: [...foodItems],
          foodFilters: {
            mainCourse: false,
            starter: false,
            dessert: false,
            soups: false,
          },
        }
      ) => state,
      orders: (
        state = {
          orders: [
            {
                id: 1,
                restaurant: {
                  image: "https://example.com/image.jpg",
                  name: "Test Restaurant",
                  location: "Test Location",
                },
                items: [
                  { id: 1, name: "Pizza", qty: 2 },
                  { id: 2, name: "Burger", qty: 1 },
                ],
                date: "2025-01-19",
                time: "12:30 PM",
                price: 350,
              }
          ],
        }
      ) => state,
    },
  });
  
  jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'), // Keep the actual imports from react-router-dom
    useNavigate: jest.fn(), // Mock useNavigate function
  }));
  
  
const renderWithStore = (store) => {
  return render(
    <Provider store={store}>
      <Router>
        <FoodGrid />
      </Router>
    </Provider>
  );
};

describe("FoodGrid Component", () => {

  it("displays restaurant information correctly", () => {
    
    renderWithStore(mockStore);

    // Check if restaurant name is rendered
    expect(screen.getByText("Restaurant 1")).toBeInTheDocument();
    // Check if rating is rendered
    expect(screen.getByText("⭐ 4.5")).toBeInTheDocument();
    // Check if price is rendered
    expect(screen.getByText("₹250")).toBeInTheDocument();
    // Check if delivery time is rendered
    expect(screen.getByText("30 mins")).toBeInTheDocument();
  });

  it("navigates to the menu page when a food item is clicked", () => {

    const navigate = jest.fn();

    useNavigate.mockReturnValue(navigate);

    renderWithStore(mockStore);

    const text = screen.getByText('Restaurant 1');
    fireEvent.click(text);

    // Expect the navigate function to have been called with the correct path
    expect(navigate).toHaveBeenCalledWith("/menu/1");
  });
});
