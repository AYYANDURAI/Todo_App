import React from 'react';
import { useNavigate } from "react-router-dom";
import './foodGrid.css';  // CSS file for styles
import { useSelector } from "react-redux";


function FoodGrid() {

const { filteredRestaurants } = useSelector((state) => state.restaurants);

const navigate = useNavigate();
const handleFoodClick = (data) =>{
    navigate(`/menu/${data.id}`)
}

  return (
    <div className="food-grid">
      <div className="grid-container cursor-pointer">
        {filteredRestaurants?.map((food, index) => (
          <div key={index} className="food-item" onClick={() => handleFoodClick(food)}>
            <img className="food-img-res" alt={food.name} src={food.image} />
            <div className="food-info p-3">
            <div className='d-flex align-items-center justify-content-between'>
              <h4>{food.name}</h4>
              <p className="rating">⭐ {food.rating}</p>
              </div>
            <div className='d-flex align-items-center justify-content-between gap-3'>
              <p>{food.foodType}</p>
              <p>{food.price}</p>
              </div>
              <div className='d-flex align-items-center justify-content-end'>
              <p className="delivery-time">{food.deliveryTime}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default FoodGrid;
