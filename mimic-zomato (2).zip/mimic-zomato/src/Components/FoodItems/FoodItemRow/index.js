import React, { useState } from "react";
import "./foodItemRow.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import Modal from "react-bootstrap/Modal";
import { useDispatch } from "react-redux";
import { addToCart } from "../../../Redux/Slices/CartSlice";
import { ToastContainer, toast, Bounce } from "react-toastify";

const FoodItemRow = ({ item, restaurant }) => {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const dispatch = useDispatch();

  const { id, name, price, image_url } = item;

  const notify = () =>
    toast("Items Added!", {
      position: "bottom-center",
      autoClose: 50000,
      hideProgressBar: false,
      closeOnClick: false,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "dark",
      transition: Bounce,
    });

  const handleAddToCart = () => {
    notify();
    dispatch(
      addToCart({
        id,
        name,
        image_url,
        price,
        qty: 1,
        restId: restaurant[0].id,
        restaurant: restaurant,
      })
    );
  };

  return (
    <div className="max-width">
      <div className="food-card">
        <div className="food-details">
          <div className="info-rating">
          <div className="food-info">
            <div className="veg-icon">
              <div className="circle"></div>
            </div>
            <div className="title-info">
              <h5 className="food-title">{item.name}</h5>
              <p className="food-price">₹{item.price}</p>
            </div>
          </div>
          <div className="food-rating">
            <FontAwesomeIcon icon={faStar} className="star-icon" />
            <span className="rating-value">{item.rating}</span>
            <span className="rating-count">({item.ratingCount})</span>
          </div>
          </div>
          <p className="food-description">{item.description}</p>
        </div>

        {/* Right Section */}
        <div className="food-image-container">
          <div>
            <img
              src={item.image_url}
              alt={item.name}
              className="food-image"
              onClick={handleShow}
            />
          </div>
          <button className="add-button" onClick={handleAddToCart}>
            ADD
          </button>
        </div>
      </div>
      <ToastContainer
        position="bottom-center"
        autoClose={10000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick={false}
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="dark"
        transition={Bounce}
      />
      <Modal
        className="food-item-modal"
        show={show}
        onHide={handleClose}
        animation={false}
        backdropClassName="custom-backdrop"
      >
        <Modal.Body>
          <div className="food-card-modal" data-testid="food-card-modal">
            <img
              className="close-icon"
              alt="modal-close-icon"
              src="/close.png"
              onClick={handleClose}
            />
            <img
              className="food-img-modal"
              alt={item.name}
              src={item.image_url}
            />
            <div className="food-details-modal">
              <div className="food-info-modal">
                <div className="veg-icon-modal">
                  <div className="circle-modal"></div>
                </div>
                <div className="title-info-modal">
                  <h5 className="food-title-modal">{item.name}</h5>
                  <p className="food-price-modal">₹{item.price}</p>
                </div>
              </div>
              <button className="add-button-modal" onClick={handleAddToCart}>
                ADD
              </button>
            </div>
            <div>
              <p className="food-description-modal">{item.description}</p>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default FoodItemRow;
