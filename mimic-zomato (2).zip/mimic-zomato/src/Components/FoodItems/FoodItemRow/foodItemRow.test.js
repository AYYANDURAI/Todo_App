import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import { configureStore } from '@reduxjs/toolkit';
import FoodItemRow from './index';
import cartReducer from '../../../Redux/Slices/CartSlice';
import { toast } from 'react-toastify';

// Mock dependencies
jest.mock('react-toastify', () => ({
  toast: jest.fn(),
  ToastContainer: () => <div data-testid="toast-container">Toast Container</div>,
  Bounce: 'bounce'
}));

jest.mock('@fortawesome/react-fontawesome', () => ({
  FontAwesomeIcon: () => <div data-testid="star-icon">★</div>
}));

describe('FoodItemRow Component', () => {
  const mockItem = {
    id: 1,
    name: 'Butter Chicken',
    price: 299,
    image_url: '/butter-chicken.jpg',
    description: 'Creamy butter chicken curry',
    rating: 4.5,
    ratingCount: 200
  };

  const mockRestaurant = [{
    id: 101,
    name: 'Test Restaurant'
  }];

  let store;

  beforeEach(() => {
    store = configureStore({
      reducer: {
        cart: cartReducer
      }
    });

    // Clear toast mock calls between tests
    toast.mockClear();
  });

  const renderComponent = () => {
    return render(
      <Provider store={store}>
        <FoodItemRow item={mockItem} restaurant={mockRestaurant} />
      </Provider>
    );
  };

  // Basic Rendering Tests
  describe('Rendering', () => {
    it('renders food item details correctly', () => {
      renderComponent();

      expect(screen.getByText(mockItem.name)).toBeInTheDocument();
      expect(screen.getByText(`₹${mockItem.price}`)).toBeInTheDocument();
      expect(screen.getByText(mockItem.description)).toBeInTheDocument();
      expect(screen.getByText(mockItem.rating)).toBeInTheDocument();
      expect(screen.getByText(`(${mockItem.ratingCount})`)).toBeInTheDocument();
    });

    it('renders food image with correct attributes', () => {
      renderComponent();
      
      const image = screen.getByAltText(mockItem.name);
      expect(image).toBeInTheDocument();
      expect(image).toHaveAttribute('src', mockItem.image_url);
      expect(image).toHaveClass('food-image');
    });

    it('renders ADD button', () => {
      renderComponent();
      expect(screen.getByText('ADD')).toBeInTheDocument();
    });
  });

  // Interaction Tests
  describe('Interactions', () => {
    it('opens modal when clicking on food image', () => {
      renderComponent();
      
      const foodImage = screen.getByAltText(mockItem.name);
      fireEvent.click(foodImage);
      
      // Check if modal content is visible
      expect(screen.getByTestId('food-card-modal')).toBeInTheDocument();
    });

    it('closes modal when clicking close button', () => {
      renderComponent();
      
      // Open modal first
      const foodImage = screen.getByAltText(mockItem.name);
      fireEvent.click(foodImage);
      
      // Click close button
      const closeButton = screen.getByAltText('modal-close-icon');
      fireEvent.click(closeButton);
      
      // Check if modal is closed
      expect(screen.queryByTestId('food-card-modal')).not.toBeInTheDocument();
    });

    it('dispatches addToCart action and shows toast when clicking ADD button', async () => {
      renderComponent();
      
      const addButton = screen.getByText('ADD');
      fireEvent.click(addButton);

      // Check if toast was called
      expect(toast).toHaveBeenCalledWith('Items Added!', expect.any(Object));

      // Check if item was added to cart in Redux store
      await waitFor(() => {
        const state = store.getState();
        const cartItems = state.cart.cart;
        expect(cartItems).toContainEqual(expect.objectContaining({
          id: mockItem.id,
          name: mockItem.name,
          price: mockItem.price,
          qty: 1,
          restId: mockRestaurant[0].id
        }));
      });
    });
  });

  // Redux Integration Tests
  describe('Redux Integration', () => {
    it('adds correct item data to cart', async () => {
      renderComponent();
      
      const addButton = screen.getByText('ADD');
      fireEvent.click(addButton);

      await waitFor(() => {
        const state = store.getState();
        const addedItem = state.cart.cart[0];
        
        expect(addedItem).toEqual({
          id: mockItem.id,
          name: mockItem.name,
          image_url: mockItem.image_url,
          price: mockItem.price,
          qty: 1,
          restId: mockRestaurant[0].id,
          restaurant: mockRestaurant
        });
      });
    });
  });

  // Edge Cases
  describe('Edge Cases', () => {
    it('handles missing image_url gracefully', () => {
      const itemWithoutImage = { ...mockItem, image_url: undefined };
      render(
        <Provider store={store}>
          <FoodItemRow item={itemWithoutImage} restaurant={mockRestaurant} />
        </Provider>
      );
      
      const image = screen.getByAltText(itemWithoutImage.name);
      expect(image.getAttribute('src')).toBeNull();
    });

    it('handles missing rating and ratingCount gracefully', () => {
      const itemWithoutRating = {
        ...mockItem,
        rating: undefined,
        ratingCount: undefined
      };
      
      render(
        <Provider store={store}>
          <FoodItemRow item={itemWithoutRating} restaurant={mockRestaurant} />
        </Provider>
      );
      
      expect(screen.getByTestId('star-icon')).toBeInTheDocument();
      expect(screen.queryByText('(undefined)')).not.toBeInTheDocument();
    });
  });
});