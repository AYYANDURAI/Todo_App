import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import MappingData from "../../MockData/mapping.json";
import FoodData from "../../MockData/foodItems.json";
import FoodItemRow from "./FoodItemRow";
import Header from "../Common/header";
import Cart from "../Cart";
import RestaurantDetails from "../RestaurantDetails";
import Filters from "../Common/Filters/index";
import { updateFoodItems } from "../../Redux/Slices/FoodItemsSlice";

import './foodItems.css';

const filtersData = [
  {
    id: 1,
    icon: <i className="fi fi-rr-settings-sliders absolute-center"></i>,
    title: "Filters",
    filters: "Filters",
  },
  {
    id: 2,
    title: "Main Course",
    key: "mainCourse",
    value: true,
  },
  {
    id: 3,
    title: "Starter",
    key: "starter",
    value: true,
  },
  {
    id: 4,
    title: "Dessert",
    key: "dessert",
    value: true,
  },
  {
    id: 5,
    title: "Soups",
    key: "soups",
    value: true,
  },
];

const FoodItem = () => {
  const params = useParams();
  const dispatch = useDispatch();
  const restId = params?.restaurantId;
  const { filteredFoodItems } = useSelector((state) => state.foodItems);
  const { filteredRestaurants } = useSelector((state) => state.restaurants);
  const restaurant = filteredRestaurants.filter((restaurant) => restaurant.id === Number(restId));
  
  
  useEffect(() => {
    const foodIds = MappingData.filter((data) => {
      return data.restaurant_ids.includes(Number(restId));
    });
    const ids = foodIds.map((id) => id.food_id);
    const data = FoodData.filter((food) => ids.includes(food.id));
    dispatch(updateFoodItems(data));
  },[dispatch, restId]);

  return (
    <div className="max-width">
      <Header />
      <Cart restaurant={restaurant} />
      <RestaurantDetails restaurant={restaurant[0]}/>
      <div className="filter-section">
        <Filters filterList={filtersData} from="foodItems"/>
      </div>
      <div className="container mt-4 food-card-container">
        {filteredFoodItems?.map((item) => (
          <div key={item.id}><FoodItemRow item={item} restaurant={restaurant}/></div>
        ))}
      </div>
    </div>
  );
};

export default FoodItem;
