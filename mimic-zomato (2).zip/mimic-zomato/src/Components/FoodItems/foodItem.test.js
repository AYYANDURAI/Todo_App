import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { configureStore } from '@reduxjs/toolkit';
import FoodItem from './index';
import foodItemsReducer from '../../Redux/Slices/FoodItemsSlice';
import restaurantsReducer from '../../Redux/Slices/RestaurantSlice';

// Mock the imported data
jest.mock('../../MockData/mapping.json', () => ([
  {
    restaurant_ids: [1],
    food_id: 101
  },
  {
    restaurant_ids: [1],
    food_id: 102
  }
]));

jest.mock('../../MockData/foodItems.json', () => ([
  {
    id: 101,
    name: "Butter Chicken",
    category: "mainCourse",
    price: 299
  },
  {
    id: 102,
    name: "Gulab Jamun",
    category: "dessert",
    price: 99
  }
]));

// Mock child components
jest.mock('../Common/header', () => {
  return function DummyHeader() {
    return <div data-testid="header">Header</div>;
  };
});

jest.mock('../Cart', () => {
  return function DummyCart({ restaurant }) {
    return <div data-testid="cart">Cart Component</div>;
  };
});

jest.mock('../RestaurantDetails', () => {
  return function DummyRestaurantDetails({ restaurant }) {
    return <div data-testid="restaurant-details">Restaurant Details</div>;
  };
});

jest.mock('../Common/Filters', () => {
  return function DummyFilters({ filterList, from }) {
    return <div data-testid="filters">Filters Component</div>;
  };
});

jest.mock('./FoodItemRow', () => {
  return function DummyFoodItemRow({ item, restaurant }) {
    return <div data-testid="food-item-row">{item.name}</div>;
  };
});

describe('FoodItem Component', () => {
  let store;

  beforeEach(() => {
    store = configureStore({
      reducer: {
        foodItems: foodItemsReducer,
        restaurants: restaurantsReducer,
      },
      preloadedState: {
        foodItems: {
          filteredFoodItems: [
            {
              id: 101,
              name: "Butter Chicken",
              category: "mainCourse",
              price: 299
            }
          ]
        },
        restaurants: {
          filteredRestaurants: [
            {
              id: 1,
              name: "Test Restaurant",
              rating: 4.5
            }
          ]
        }
      }
    });
  });

  const renderComponent = () => {
    return render(
      <Provider store={store}>
        <MemoryRouter initialEntries={['/restaurant/1']}>
          <Routes>
            <Route path="/restaurant/:restaurantId" element={<FoodItem />} />
          </Routes>
        </MemoryRouter>
      </Provider>
    );
  };

  it('renders all child components correctly', () => {
    renderComponent();
    
    expect(screen.getByTestId('header')).toBeInTheDocument();
    expect(screen.getByTestId('cart')).toBeInTheDocument();
    expect(screen.getByTestId('restaurant-details')).toBeInTheDocument();
    expect(screen.getByTestId('filters')).toBeInTheDocument();
  });

  it('displays food items from Redux store', () => {
    renderComponent();
    
    expect(screen.getByText('Butter Chicken')).toBeInTheDocument();
  });

  it('dispatches updateFoodItems action on mount', async () => {
    renderComponent();
    
    await waitFor(() => {
      const state = store.getState();
      expect(state.foodItems.filteredFoodItems).toBeTruthy();
    });
  });

  it('filters food items based on restaurant ID from URL params', async () => {
    renderComponent();
    
    await waitFor(() => {
      const state = store.getState();
      const filteredItems = state.foodItems.filteredFoodItems;
      expect(filteredItems.every(item => 
        item.id === 101 || item.id === 102
      )).toBeTruthy();
    });
  });

  // Test error states
  it('handles missing restaurant data gracefully', () => {
    store = configureStore({
      reducer: {
        foodItems: foodItemsReducer,
        restaurants: restaurantsReducer,
      },
      preloadedState: {
        foodItems: {
          filteredFoodItems: []
        },
        restaurants: {
          filteredRestaurants: []
        }
      }
    });

    renderComponent();
    
    // Component should render without crashing
    expect(screen.getByTestId('header')).toBeInTheDocument();
  });
});