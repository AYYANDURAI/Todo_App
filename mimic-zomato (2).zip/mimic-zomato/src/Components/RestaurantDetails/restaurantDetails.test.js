import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import RestaurantDetails from './index';

describe('RestaurantDetails Component', () => {
  const mockRestaurant = {
    name: 'The Great Restaurant',
    rating: '4.5',
    foodType: ['Italian', 'Continental'],
    location: 'Downtown',
    ratingCount: '1200',
    contact: '9876543210',
  };

  it('should render restaurant details correctly', () => {
    render(<RestaurantDetails restaurant={mockRestaurant} />);

    // Check if restaurant name is rendered
    expect(screen.getByText('The Great Restaurant')).toBeInTheDocument();

    // Check if food type and location are rendered
    expect(screen.getByText('Italian Continental')).toBeInTheDocument();
    expect(screen.getByText('Downtown')).toBeInTheDocument();

    // Check if contact information is rendered with +91 prefix
    expect(screen.getByText('+919876543210')).toBeInTheDocument();

    // Check if rating and review count are rendered
    expect(screen.getByText('4.5')).toBeInTheDocument();
    expect(screen.getByText('1200')).toBeInTheDocument();
  });

  it('should merge foodType array into a space-separated string', () => {
    render(<RestaurantDetails restaurant={mockRestaurant} />);

    // Check if the merged foodType is rendered correctly
    expect(screen.getByText('Italian Continental')).toBeInTheDocument();
  });

  it('should render correct location if foodType is not an array', () => {
    const mockRestaurantWithoutFoodType = {
      ...mockRestaurant,
      foodType: 'Indian',
    };

    render(<RestaurantDetails restaurant={mockRestaurantWithoutFoodType} />);
    let text = screen.queryAllByText('Downtown')[0];
    // Check if location is used instead of foodType
    expect(text).toBeInTheDocument();
    expect(screen.queryByText('Italian Continental')).not.toBeInTheDocument();
  });

  it('should render open timing information', () => {
    render(<RestaurantDetails restaurant={mockRestaurant} />);

    // Check if the timing is rendered correctly
    expect(screen.getByText(/Open now/i)).toBeInTheDocument();
    expect(screen.getByText(/7am.+10pm.+Today/)).toBeInTheDocument();
  });

  it('should render the correct image for the phone call', () => {
    render(<RestaurantDetails restaurant={mockRestaurant} />);

    // Check if the phone call image is rendered
    const callImage = screen.getByAltText('call-img');
    expect(callImage).toBeInTheDocument();
    expect(callImage.src).toContain('/phone-call.png');
  });
});
