import React from "react";
import "./restaurantDetails.css";

const RestaurantDetails = ({ restaurant }) => {
  const { name, rating, foodType, location, ratingCount, contact } = restaurant;

  const mergeLocation = (foodType) => {
    if (Array.isArray(foodType)) {
      return foodType?.join(" ");
    } else return location;
  };
  return (
    <div className="max-width">
      <div className="restaurant-details">
        <div className="restaurant-details-left">
          <div className="restaurant-details-info">
            <h1 className="hotel-title">{name}</h1>
            <span className="hotel-type">{mergeLocation(foodType)}</span>
            <span className="hotel-address">{location}</span>
          </div>
          <div className="restaurant-timing-info">
            <div className="timing">
              <span className="hotel-avail">Open now</span>
              <span className="hotel-timing">- 7am – 10pm (Today)</span>
            </div>

            <span className="res-mobile bYfdkw">
              {" "}
              <img
                className="call-pic"
                src="/phone-call.png"
                alt="call-img"
              />{" "}
              +91{contact}
            </span>
          </div>
        </div>
        <div className="restaurant-details-right">
          <div className="star-rating">
            <span>{parseFloat(rating)}</span>
            <i className="fi fi-ss-star"></i>
          </div>
          <div className="dining-rating">
            <span className="rating-count">{ratingCount}</span>
            <span className="count-title">Delivery Ratings</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantDetails;
