import React, { useState } from "react";
import "./header.css";
import Dropdown from "react-bootstrap/Dropdown";
import { useNavigate } from "react-router-dom";
import Cart from "../../Cart";

const Header = () => {
  const [activeCart, setActiveCart] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const navigate = useNavigate();

  return (
    <div className="max-width header w-full">
      <div className="header-right">
        <div className="header-navbar">
          <button
            
            className="menu-toggle"
            onClick={() => setIsMobile(!isMobile)}
          >
            {isMobile ? "X" : "☰"}
          </button>
        </div>
        <img
          src="https://b.zmtcdn.com/web_assets/b40b97e677bc7b2ca77c58c61db266fe1603954218.png"
          className="header-logo"
          alt="logo"
        />
      </div>
      <div data-testid="header-lefts" className={`${isMobile ? "header-left active" : "header-left"}`}>
        <div className="header-location-search-container">
          <div className="location-wrapper">
            <div className="location-icon-name">
              <i className="fi fi-rr-marker absolute-center location-icon"></i>
              <div>Bangalore</div>
            </div>
            <i className="fi fi-rr-caret-down absolute-center"></i>
          </div>
          <div className="location-separator"></div>
          <div className="header-searchbar">
            <i className="fi fi-rr-search absolute-center search-icon"></i>
            <input
              placeholder="Search for restaurant, cuisine or a dish"
              className="search-input"
            />
          </div>
        </div>
          <div className="profile-wrapper">
            <img
              className="header-profile-image"
              alt="profile-image"
              src="https://b.zmtcdn.com/web/assets/2267aec184e096c98c46a1565a5563661664945464.png?fit=around%7C200%3A200&crop=200%3A200%3B%2A%2C%2A"
            />
            <span className="header-username">Ayyandurai</span>
            <Dropdown className="order-dropdown" name="order-dropdown">
              <Dropdown.Toggle className="order-btn" data-testid="dropdown-basic">
                <i className="fi fi-br-angle-down absolute-center profile-options-icons pl-0"></i>
              </Dropdown.Toggle>
              <Dropdown.Menu className="custom-dropdown-menu" data-testid="menu">
                <Dropdown.Item
                  data-testid="orders-link"
                  className="custom-dropdown-item"
                  name="orders-page"
                  onClick={() => navigate("/orders")}
                >
                  Orders
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
          <div className="carts flex justify-between w-[55px] mt-1 items-center md:pl-1 sm:pl-2 gap-1 pl-2">
            <i
              className="fi fi-sr-briefcase-blank cursor-pointer"
              onClick={() => setActiveCart(!activeCart)}
            ></i>
            <p className="mb-1" onClick={() => setActiveCart(!activeCart)}>
              Cart
            </p>
        </div>
      </div>
      <Cart activeCart={activeCart} setActiveCart={setActiveCart} />
    </div>
  );
};

export default Header;
