import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { BrowserRouter as Router } from 'react-router-dom';
import Header from './index';
import { useNavigate } from 'react-router-dom';
import { Provider } from 'react-redux';
import foodItems from "../../../MockData/foodItems.json";
import restaurants from "../../../MockData/restaurants.json";
import { configureStore } from "@reduxjs/toolkit";

const store = configureStore({
    reducer: {
      cart: (
        state = {
          cart: [
            {
              id: 1,
              name: "",
              image_url: "",
              price: 200,
              qty: 1,
              restId: 2,
              restaurant: restaurants[0],
            },
          ],
        }
      ) => state,
      restaurants: (
        state = {
          filteredRestaurants: [...restaurants],
          filters: {
            rating: false,
            isVeg: false,
            isNonVeg: false,
            deliveryTime: null,
          },
        }
      ) => state,
      foodItems: (
        state = {
          filteredFoodItems: [...foodItems],
          foodFilters: {
            mainCourse: false,
            starter: false,
            dessert: false,
            soups: false,
          },
        }
      ) => state,
      orders: (
        state = {
          orders: [
            {
              id: 3,
              restaurant: restaurants[0],
              items: foodItems,
              date: "",
              time: "",
              price: "300",
            },
          ],
        }
      ) => state,
    },
  });

// Mock the useNavigate hook
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}));

describe('Header Component', () => {

  it('should render static elements correctly', () => {
    render(
        <Provider store={store}>
      <Router>
        <Header />
      </Router>
      </Provider>
    );

    // Check if the logo image is rendered
    const logo = screen.getByAltText('logo');
    expect(logo).toBeInTheDocument();
    expect(logo).toHaveAttribute('src', 'https://b.zmtcdn.com/web_assets/b40b97e677bc7b2ca77c58c61db266fe1603954218.png');

    // Check if the profile image is rendered
    const profileImage = screen.getByAltText('profile-image');
    expect(profileImage).toBeInTheDocument();

    // Check if the username is rendered
    const username = screen.getByText('Ayyandurai');
    expect(username).toBeInTheDocument();
  });

  it('should toggle mobile menu on button click', () => {
    render(
        <Provider store={store}>
      <Router>
        <Header />
      </Router>
      </Provider>
    );

    // Initially, the mobile menu should be hidden
    const headerLeft = screen.getByTestId('header-lefts');
    expect(headerLeft).not.toHaveClass('active');

    // Click the menu toggle button to open the mobile menu
    const menuToggle = screen.getByRole('button', { name: /☰/i });     

    // Now, the mobile menu should be visible
    expect(headerLeft).toHaveClass('header-left');
    expect(menuToggle).toHaveTextContent('☰'); // Button should show "X" after click
  });

  it('should toggle the cart visibility', () => {
    render(
        <Provider store={store}>
      <Router>
        <Header />
      </Router>
      </Provider>
    );

    // Initially, the cart is closed
    const cart = screen.queryByText('Cart');
    expect(cart).toBeInTheDocument();

    // Click the cart icon to toggle the cart state
    const cartButton = screen.getByText('Cart');
    fireEvent.click(cartButton);

    // Check if the cart is opened (activeCart state toggled)
    // You would need to mock the Cart component and check if it's being displayed
    // For now, just check for the Cart button toggle effect.
    expect(cartButton).toBeInTheDocument();
  });

  it('should navigate to orders page when "Orders" is clicked in the dropdown', async() => {

    const navigate = jest.fn();

    useNavigate.mockReturnValue(navigate);

    render(
        <Provider store={store}>
      <Router>
        <Header />
      </Router>
      </Provider>
    );

    // Open the dropdown
    const dropdownToggle = screen.getByTestId('dropdown-basic');
    fireEvent.click(dropdownToggle);

    // Click the "Orders" dropdown item
    const ordersItem = screen.getByTestId('orders-link');
    fireEvent.click(ordersItem);
    await waitFor( () => {
    // Ensure the navigate function was called with the correct URL
    expect(navigate).toHaveBeenCalledWith('/orders');
    });
  });

  it('should open and close the profile dropdown', async() => {
    render(
        <Provider store={store}>
      <Router>
        <Header />
      </Router>
      </Provider>
    );

    // Open the dropdown
    const dropdownToggle = screen.getByTestId('dropdown-basic');
    fireEvent.click(dropdownToggle);

    // Ensure the dropdown menu is visible
    expect(screen.getByTestId('menu')).toBeInTheDocument();

    // Close the dropdown
    fireEvent.click(dropdownToggle);
  });
});
