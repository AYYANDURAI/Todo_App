import React from 'react'
import './filters.css';
import FilterItem from '../FilterItem';

const Filters = ({ filterList, from }) => {
  return (
    <div className='filters'>
      {
        filterList && filterList.map((filter) => {
            return <div key={filter.id}><FilterItem from={from} id={filter.id} filter={filter} /></div>
        })
      }
    </div>
  )
}

export default Filters
