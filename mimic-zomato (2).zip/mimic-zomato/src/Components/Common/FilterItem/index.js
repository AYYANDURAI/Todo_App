import React from "react";
import {
  addFilters,
  filterRestaurants,
} from "../../../Redux/Slices/RestaurantSlice";
import {
  addFoodFilters,
  filterFoodItems,
} from "../../../Redux/Slices/FoodItemsSlice";
import { useDispatch, useSelector } from "react-redux";
import "./filterItem.css";

const FilterItem = ({ filter, id, from }) => {
  const dispatch = useDispatch();
  const { filters } = useSelector((state) => state.restaurants);
  const { foodFilters } = useSelector((state) => state.foodItems);
  

  const handleFilter = (filter) => {
    if (from === "restaurants") {
      dispatch(addFilters({ key: filter.key, value: !filters[filter.key] }));
      dispatch(filterRestaurants());
    }else{
      dispatch(addFoodFilters({ key: filter.key, value: !foodFilters[filter.key] }));
      dispatch(filterFoodItems());
    }
  };
  const getButtonStyle = (filters, filterKey) => {
    const isActive = filters[filterKey];
    return {
      backgroundColor: isActive ? "#ff4d4d" : "var(--primary-bg)", 
      padding: "8px",
      display: "flex",
      color: isActive ? "white" : "var(--filter-text)",
      border: isActive ? "none" : "1px solid var(--grey)",
      borderRadius: "8px",
      margin: "10px 10px 10px 0px",
      fontSize: "14px",
      cursor: "pointer",
    };
  };

  return (
    <div
      className="filter-item"
      style={getButtonStyle(from === "restaurants" ? filters : foodFilters, filter.key)}
      onClick={() => handleFilter(filter)}
      key={id}
    >
      {filter.icon && filter.icon}
      <div className="filter-name" data-testid="filter-name">{filter.title}</div>
    </div>
  );
};

export default FilterItem;
