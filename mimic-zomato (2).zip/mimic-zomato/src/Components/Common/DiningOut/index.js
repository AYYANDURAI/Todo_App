import React from 'react'

const DiningOut = () => {
  return (
    <div>
      <p>Dining Out</p>
    </div>
  )
}

export default DiningOut
