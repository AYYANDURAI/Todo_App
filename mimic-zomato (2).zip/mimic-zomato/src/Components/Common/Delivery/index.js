import React from "react";
import Filters from "../Filters";
import DeliveryCollections from "./deliveryCollections";

const deliveryFilters = [
  {
    id: 1,
    icon: <i className="fi fi-rr-settings-sliders absolute-center"></i>,
    title: 'Filters',
    filters: 'Filters'
  },
  {
    id: 2,
    title: 'Rating 4.0+',
    key: "rating",
    value: true
  },
  {
    id: 3,
    title: 'Non Veg',
    key: "isNonVeg",
    value: true
  },
  {
    id: 4,
    title: 'Pure Veg',
    key: 'isVeg',
    value: true
  }
]

const Delivery = () => {
  return (
    <div>
      <DeliveryCollections/>
      <div className="max-width">
        <Filters filterList={deliveryFilters} from="restaurants"/>
      </div>
    </div>
  );
};

export default Delivery;
