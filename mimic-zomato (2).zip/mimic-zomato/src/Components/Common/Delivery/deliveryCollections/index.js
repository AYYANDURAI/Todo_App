import React from "react";
import UncontrolledExample from "../../../Carousel";

const DeliveryCollections = () => {
  return (
    <div className="delivery-collection">
      <div className="max-width">
        <UncontrolledExample />
      </div>
    </div>
  );
};

export default DeliveryCollections;
