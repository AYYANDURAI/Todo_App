import React from 'react'

const NightLife = () => {
  return (
    <div>
      <p>This is nightlife</p>
    </div>
  )
}

export default NightLife
