import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import Cart from './index';
import { BrowserRouter } from 'react-router-dom';
import { configureStore } from "@reduxjs/toolkit";
import { useNavigate } from 'react-router-dom';

// Create a mock Redux store
const mockStore = configureStore({
    reducer: {
      cart: (
        state = {
          cart:  [
            {
              id: 1,
              name: 'Pizza',
              price: 200,
              qty: 1,
              image_url: 'https://example.com/pizza.jpg',
              restId: 'restaurant1',
            },
            {
              id: 2,
              name: 'Burger',
              price: 100,
              qty: 2,
              image_url: 'https://example.com/burger.jpg',
              restId: 'restaurant1',
            },
          ],
        }
      ) => state,
    },
  });
  jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'), // Keep the actual imports from react-router-dom
    useNavigate: jest.fn(), // Mock useNavigate function
  }));
const MockedCart = ({ activeCart, setActiveCart }) => (
  <Provider store={mockStore}>
    <BrowserRouter>
      <Cart activeCart={activeCart} setActiveCart={setActiveCart} />
    </BrowserRouter>
  </Provider>
);

describe('Cart Component', () => {
  it('renders correctly with cart items', () => {
    render(<MockedCart activeCart={true} setActiveCart={() => {}} />);
    
    expect(screen.getByText(/My Order/i)).toBeInTheDocument();
    expect(screen.getByText(/Pizza/i)).toBeInTheDocument();
    expect(screen.getByText(/Burger/i)).toBeInTheDocument();
  });

  it('increments the quantity when + button is clicked', () => {
    render(<MockedCart activeCart={true} setActiveCart={() => {}} />);
    
    const incrementButton = screen.getAllByText('+')[0]; // Pizza has the first + button
    fireEvent.click(incrementButton);
    
    // Check if the quantity has increased
    expect(screen.getByText('2')).toBeInTheDocument(); // Pizza's quantity should now be 2
  });

  it('decrements the quantity when - button is clicked', () => {
    render(<MockedCart activeCart={true} setActiveCart={() => {}} />);
    
    const decrementButton = screen.getAllByText('−')[1]; // Burger has the second - button
    fireEvent.click(decrementButton);
    
    // Check if the quantity has decreased
    expect(screen.getByText('1')).toBeInTheDocument(); // Burger's quantity should now be 1
  });

//   it('removes item from cart when quantity is decremented to 0', async() => {
//     const setActiveCart = jest.fn(); // Mock the setActiveCart function

//     render(<MockedCart activeCart={true} setActiveCart={setActiveCart} />);

//     const decrementButton = screen.getByRole('button', { name: /decrease-burger/i });
      
//       // Click the decrement button
//       fireEvent.click(decrementButton);
      
//       // Check that the Burger item is no longer in the DOM
//       expect(screen.queryByText('Burger')).toBeNull();
//   });

  it('calls handleOrders and navigates when Checkout is clicked', async () => {
    const navigate = jest.fn();
    const setActiveCart = jest.fn();

    useNavigate.mockReturnValue(navigate);
    
    render(<MockedCart activeCart={true} setActiveCart={setActiveCart} />);
    
    // Mock the navigate function
    jest.spyOn(require('react-router-dom'), 'useNavigate').mockReturnValue(navigate);

    const checkoutButton = screen.getByText('Checkout');
    fireEvent.click(checkoutButton);
    
    // Check if the navigate function was called with the correct path
    await waitFor(() => {
      expect(navigate).toHaveBeenCalledWith('/orders');
    });
  });

  it('toggles cart visibility when close button is clicked', () => {
    const setActiveCart = jest.fn();
    render(<MockedCart activeCart={true} setActiveCart={setActiveCart} />);
    
    const closeButton = screen.getByTestId('close-icon'); 
    fireEvent.click(closeButton);   
    
    expect(setActiveCart).toHaveBeenCalledWith(false);
  });
});
