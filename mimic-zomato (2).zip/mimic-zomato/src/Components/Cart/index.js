import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { incrementQty, decrementQty, removeFromCart, resetCart } from "../../Redux/Slices/CartSlice";
import { addOrder } from "../../Redux/Slices/OrdersSlice";
import { useNavigate } from "react-router-dom";

import "./cart.css";

const Cart = ({ activeCart, setActiveCart }) => {
  const navigate = useNavigate();
  
  const cartItems = useSelector((state) => state.cart.cart);
  const totalQty = cartItems.reduce((totalQty, item) => totalQty + item.qty, 0);
  const totalPrice = cartItems.reduce((totalPrice, item) => totalPrice + (item.qty * item.price), 0);
  const dispatch = useDispatch();

  const handleIncrement = (item) => {
    if(item.qty >= 1) dispatch(incrementQty(item));
  };

  const handleDecrement = (item) => {
    if(item.qty === 1) dispatch(removeFromCart(item))
    else dispatch(decrementQty(item));
  };

  const handleOrders = () => {

    const date = new Date();

    const time = date.toLocaleString([], {
          hour: "2-digit",
          minute: "2-digit",
    });

    const groupedById = cartItems?.reduce((acc, obj) => {
      const key = obj.restId;
      if (!acc[key]) {
        acc[key] = []; 
      }
      acc[key].push(obj); 
      return acc;
    }, {});

    const orderDetails = {
      cart: groupedById,
      totalPrice: totalPrice,
      date: date.toLocaleDateString('en-us', {  day:"numeric", month:"short" }),
      time: time,
      orderStatus: 'success'
    }

    dispatch(addOrder(orderDetails));
    dispatch(resetCart());
    setActiveCart(!activeCart);
    navigate('/orders');
  }
  const getCartItems = () => {
    return cartItems?.map((item) => {
      return (
        <div key={item.id} className="cart shadow-md mb-2">
          <div className="cart-info">
            <img className="cart-item-img" src={item.image_url} alt="food" />
            <div className="cart-item-info">
              <div className="cart-item-name">{item.name}</div>
              <span className="cart-item-price">₹{item.price}</span>
            </div>
          </div>
          <div className="add-remove-cart">
            <button
              className="remove-cart-button hover:text-xl transition-all ease-linear"
              onClick={() => handleDecrement(item)}
              name={`decrease-${item.name.toLowerCase()}`} 
            >
              −
            </button>
            <div className="cart-item-count" data-testid="cart-item-count">{item.qty}</div>
            <button
              className="add-cart-button hover:text-xl transition-all ease-linear"
              onClick={() => handleIncrement(item)}
            >
              +
            </button>
          </div>
        </div>
      );
    });
  };
  return (
    <div
      className={`fixed right-0 top-0 w-full lg:w-[30vw] bg-white h-full p-2 ${
        activeCart ? "translate-x-0" : "translate-x-full"
      } transition-all duration-500 z-50`}
    >
      <div className="flex justify-between items-center my-3 px-2">
        <span className="text-xl font-bold text-gray-800">My Order</span>
        <i
          onClick={() => setActiveCart(!activeCart)}
          data-testid="close-icon"
          className="fi fi-tr-circle-xmark hover:text-red-400 text-xl font-bold cursor-pointer mt-1"
        />
      </div>
      {cartItems?.length > 0 ? (
        <>
          <>{getCartItems()}</>
          <div className="absolute bottom-0">
            <p className="font-semibold text-gray-800 px-2 text-left font">
              Items : { totalQty }
            </p>
            <p className="font-semibold text-gray-800 px-2 text-left">
              Total Amount : ₹ { totalPrice }
            </p>
            <hr className="my-2" />
            <div className="mt-3">
              <button
                onClick={handleOrders}
                className="bg-red-400 py-2.5 w-[90vw] lg:w-[28vw] px-4 font-bold text-white rounded-lg mb-4"
              >
                Checkout
              </button>
            </div>
          </div>
        </>
      ) : (
        " Your Cart is Empty"
      )}
    </div>
  );
};

export default Cart;
