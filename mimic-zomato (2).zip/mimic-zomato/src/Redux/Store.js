import {configureStore} from '@reduxjs/toolkit';
import CartSlice from './Slices/CartSlice';
import RestaurantSlice from './Slices/RestaurantSlice';
import FoodItemsSlice from './Slices/FoodItemsSlice';
import OrdersSlice from './Slices/OrdersSlice';

const Store = configureStore({
    reducer: {
        cart: CartSlice,
        restaurants: RestaurantSlice,
        foodItems: FoodItemsSlice,
        orders: OrdersSlice
    },
    devTools:{
        trace: true
    }
});

export default Store;