import { createSlice } from "@reduxjs/toolkit";
import restaurantData from '../../MockData/restaurants.json'

const restaurantSlice = createSlice({
    name: "restaurant",
    initialState: {
        restaurants:restaurantData,
        filters: {
            rating: false, 
            isVeg: false,  
            isNonVeg: false, 
            deliveryTime: null, 
        },
        filteredRestaurants: restaurantData
    },
    reducers: {
        filterRestaurants: (state, action) => {
            const { filters } = state;

            state.filteredRestaurants = state.restaurants.filter((restaurant) => {
                const meetsRating = !filters.rating || restaurant.rating >= 4.0;
                const meetsVeg = !filters.isVeg || restaurant.isVeg;
                const meetsNonVeg = !filters.isNonVeg || !restaurant.isVeg;            
                return meetsRating && meetsVeg && meetsNonVeg;
              })
        },
        addFilters: (state, action) => {
            const { key, value } = action.payload;
            state.filters[key] = value;
        }
    }
});

export const {filterRestaurants, addFilters} = restaurantSlice.actions;
export default restaurantSlice.reducer;