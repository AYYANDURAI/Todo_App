import { createSlice } from "@reduxjs/toolkit";

const foodItemsSlice = createSlice({
    name: "foodItems",
    initialState: {
        foodItems:[],
        foodFilters: {
            mainCourse: false, 
            starter: false,  
            dessert: false, 
            soups: false, 
        },
        filteredFoodItems: []
    },
    reducers: {
        updateFoodItems: (state, action) => {
            state.foodItems = action.payload;
            state.filteredFoodItems = action.payload;
        },
        filterFoodItems: (state, action) => {
            const { foodFilters } = state;

            state.filteredFoodItems = state.foodItems.filter((foodItem) => {
                const meetsMainCourse = !foodFilters.mainCourse || foodItem.type === 'Main Course';
                const meetsStarter = !foodFilters.starter || foodItem.type === 'Starter';
                const meetsDessert = !foodFilters.dessert || foodItem.type === 'Dessert';   
                const meetsSoups = !foodFilters.soups|| foodItem.type === 'Soup';   
                return meetsMainCourse && meetsDessert && meetsStarter && meetsSoups;
              });
        },
        addFoodFilters: (state, action) => {
            state.foodFilters = Object.entries(state.foodFilters).map((filter) => {
                if(filter.value === true){
                    filter.value = false;
                }
                return filter;
            })
            const { key, value } = action.payload;
            state.foodFilters[key] = value;
        }
    }
});

export const { updateFoodItems, filterFoodItems, addFoodFilters } = foodItemsSlice.actions;
export default foodItemsSlice.reducer;