import { createSlice } from "@reduxjs/toolkit";

const ordersSlice = createSlice({
  name: "orders",
  initialState: {
    orders: [],
  },
  reducers: {
    addOrder: (state, action) => {
      let { cart , date, time, totalPrice} = action.payload;
      for (const [key, value] of Object.entries(cart)) {
        if (!state.orders.find(d => d.id === Number(key))) 
        state.orders.push({ id: key, restaurant: value[0].restaurant[0],items: value, date: date, time: time, price: totalPrice });
      }
    },
  },
});

export const { addOrder } = ordersSlice.actions;
export default ordersSlice.reducer;
