import "./App.css";
import React from 'react'; // Import React at the top of your test file
import FoodItem from "./Components/FoodItems";
import HomePage from "./Pages/home";
import {
  Routes,
  Route,
} from "react-router-dom";
import Orders from "./Pages/Orders";

function App() {
  return (
    <div className="App">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/menu/:restaurantId" element={<FoodItem />} />
          <Route path="/orders" element={<Orders/>} />
        </Routes>
    </div>
  );
}

export default App;
