import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom"; // For routing in tests
import App from "./App"; // Assuming App.js is in the same directory
import "@testing-library/jest-dom"; // For jest-dom matchers
import { Provider } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
import foodItems from "./MockData/foodItems.json";
import restaurants from "./MockData/restaurants.json";
import React from 'react'; // Import React at the top of your test file

const store = configureStore({
  reducer: {
    cart: (
      state = {
        cart: [
          {
            id: 1,
            name: "",
            image_url: "",
            price: 200,
            qty: 1,
            restId: 2,
            restaurant: restaurants[0],
          },
        ],
      }
    ) => state,
    restaurants: (
      state = {
        filteredRestaurants: [...restaurants],
        filters: {
          rating: false,
          isVeg: false,
          isNonVeg: false,
          deliveryTime: null,
        },
      }
    ) => state,
    foodItems: (
      state = {
        filteredFoodItems: [...foodItems],
        foodFilters: {
          mainCourse: false,
          starter: false,
          dessert: false,
          soups: false,
        },
      }
    ) => state,
    orders: (
      state = {
        orders: [
          {
            id: 3,
            restaurant: restaurants[0],
            items: foodItems,
            date: "",
            time: "",
            price: "300",
          },
        ],
      }
    ) => state,
  },
});

// Test suite for App component
describe("App Component", () => {
  // Test for rendering HomePage when accessing the root route '/'
  it("renders HomePage component on the root route", () => {
    render(
      <MemoryRouter initialEntries={["/"]}>
        <Provider store={store}>
          <App />
        </Provider>
      </MemoryRouter>
    );
    // Check if HomePage content is displayed
    expect(screen.getByText(/Non Veg/i)).toBeInTheDocument();
  });

  // Test for rendering FoodItem when accessing '/menu/:restaurantId'
  it('renders FoodItem component when navigating to "/menu/:restaurantId"', () => {
    render(
      <MemoryRouter initialEntries={["/menu/1"]}>
        <Provider store={store}>
          <App />
        </Provider>
      </MemoryRouter>
    );
    // Check if FoodItem component is rendered
    expect(screen.getByText(/Delivery Ratings/i)).toBeInTheDocument();
  });

  // Test for rendering Orders when accessing '/orders'
  it('renders Orders component on the "/orders" route', () => {
    render(
      <MemoryRouter initialEntries={["/orders"]}>
        <Provider store={store}>
          <App />
        </Provider>
      </MemoryRouter>
    );
    // Check if Orders content is displayed
    expect(screen.getByText(/Your Orders/i)).toBeInTheDocument();
  });
});
